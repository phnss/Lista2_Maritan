#include <iostream>

#include "TestaValidaNumero.h"

using namespace std;

int main()
{
    TestaValidaNumero teste;

    try{
        teste.validaNumero(200);
    }catch(ValorAbaixoException erro1){
        cout<<erro1.what()<<endl;

    }catch(ValorAcimaException error2){
        cout<<error2.what()<<endl;

    }catch(ValorMuitoAcimaException error3){
        cout<<error3.what()<<endl;
    }

    try{
        teste.validaNumero(-39);
    }catch(ValorAbaixoException erro1){
        cout<<erro1.what()<<endl;

    }catch(ValorAcimaException error2){
        cout<<error2.what()<<endl;

    }catch(ValorMuitoAcimaException error3){
        cout<<error3.what()<<endl;
    }
try{
        teste.validaNumero(2000);
    }catch(ValorAbaixoException erro1){
        cout<<erro1.what()<<endl;

    }catch(ValorAcimaException error2){
        cout<<error2.what()<<endl;

    }catch(ValorMuitoAcimaException error3){
        cout<<error3.what()<<endl;
    }

    return 0;
}
