#include <iostream>
#include <locale>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    ofstream escrita;
    ifstream leitura;

    char letra;

    escrita.open("teste_bkp.txt", ios::out);
    leitura.open("teste.txt", ios::in);

    if (!escrita.is_open() || !leitura.is_open()){
        cout << "N�o foi poss�vel abrir os arquivos" << endl;

        escrita.close();
        leitura.close();

        return -1;
    }

    while(!leitura.eof()){
        if(leitura.eof()){
            break;
        }
        leitura.get(letra);
        escrita << letra;
    }

    cout << "Copia completa" << endl;
    escrita.close();
    leitura.close();

    return 0;
}
