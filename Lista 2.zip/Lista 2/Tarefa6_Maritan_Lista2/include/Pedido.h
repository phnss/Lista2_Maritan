#ifndef PEDIDO_H
#define PEDIDO_H

#include <string>

class Pedido
{
    public:
//------------CONSTRUTOR------------
        Pedido();
        Pedido(int numero, std::string descricao, int quantidade, double preco);
//------------GET-------------------
        int getNumero();
        std::string getDescricao();
        int getQuantidade();
        double getPreco();
//------------SET-------------------
        void setNumero(int numero);
        void setDescricao(std::string descricao);
        void setQuantidade(int quantidade);
        void setPreco(double preco);

    private:
        int numero;
        std::string descricao;
        int quantidade;
        double preco;
};

#endif // PEDIDO_H
