#include "ValorMuitoAcimaException.h"

ValorMuitoAcimaException::ValorMuitoAcimaException()
{
    //ctor
}

const char* ValorMuitoAcimaException::what()
{
    return "Valor muito acima do esperado.";
}
