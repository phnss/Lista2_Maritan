#ifndef VALORMUITOACIMAEXCEPTION_H
#define VALORMUITOACIMAEXCEPTION_H


class ValorMuitoAcimaException
{
    public:
        ValorMuitoAcimaException();

        const char* what();
    private:
};

#endif // VALORMUITOACIMAEXCEPTION_H
