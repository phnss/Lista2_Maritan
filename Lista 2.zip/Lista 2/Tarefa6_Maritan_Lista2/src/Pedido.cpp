#include "Pedido.h"
//------------CONSTRUTOR------------
Pedido::Pedido()
{
    this->numero = 0;
    this->descricao = "";
    this->quantidade = 0;
    this->preco = 0.0;
}
Pedido::Pedido(int numero, std::string descricao, int quantidade, double preco)
{
    this->numero = numero;
    this->descricao = descricao;
    this->quantidade = quantidade;
    this->preco = preco;
}
//------------GET-------------------
int Pedido::getNumero(){return numero;}

std::string Pedido::getDescricao(){return descricao;}

int Pedido::getQuantidade(){return quantidade;}

double Pedido::getPreco(){return preco;}
//------------SET-------------------
void Pedido::setNumero(int numero){this->numero = numero;}

void Pedido::setDescricao(std::string descricao){this->descricao = descricao;}

void Pedido::setQuantidade(int quantidade){this->quantidade = quantidade;}

void Pedido::setPreco(double preco){this->preco = preco;}
