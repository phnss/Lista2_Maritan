#include "TestaValidaNumero.h"

TestaValidaNumero::TestaValidaNumero()
{
    //ctor
}

void TestaValidaNumero::validaNumero(int num)
{
    ValorAbaixoException error1;
    ValorAcimaException error2;
    ValorMuitoAcimaException error3;

    if(num <= 0){
            throw error1;
    }else if(num > 100 && num < 1000){
            throw error2;
    }else if(num >= 1000){
            throw error3;
    }
}
