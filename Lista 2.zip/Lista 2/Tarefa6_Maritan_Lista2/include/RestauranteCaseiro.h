#ifndef RESTAURANTECASEIRO_H
#define RESTAURANTECASEIRO_H

#include "MesaDeRestaurante.h"

class RestauranteCaseiro
{
    public:
//------------CONSTRUTOR------------
        RestauranteCaseiro();
//------------GET-------------------

//------------SET-------------------

//------------M�TODOS---------------
    void adicionaAoPedido(Pedido pedido, int numMesa);
    double calculaTotalRestaurante();
    void adicionaMesa(MesaDeRestaurante mesa);

    private:
        std::vector<MesaDeRestaurante>mesas;
};

#endif // RESTAURANTECASEIRO_H
