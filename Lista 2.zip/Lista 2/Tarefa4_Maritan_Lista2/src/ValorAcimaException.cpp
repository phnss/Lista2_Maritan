#include "ValorAcimaException.h"

ValorAcimaException::ValorAcimaException()
{
    //ctor
}

const char* ValorAcimaException::what()
{
    return "Valor acima do esperado.";
}
