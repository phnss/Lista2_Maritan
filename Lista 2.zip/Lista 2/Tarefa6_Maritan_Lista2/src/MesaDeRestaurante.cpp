#include "MesaDeRestaurante.h"

//------------CONSTRUTOR------------
MesaDeRestaurante::MesaDeRestaurante()
{
    //ctor
}
MesaDeRestaurante::MesaDeRestaurante(Pedido pedido)
{
    pedidos.push_back(pedido);
}
//------------GET-------------------
//------------SET-------------------
//------------M�TODOS---------------
void MesaDeRestaurante::adicionaAoPedido(Pedido pedido){pedidos.push_back(pedido);}

void MesaDeRestaurante::zeraPedidos(){pedidos.clear();}

double MesaDeRestaurante::calculaTotal()
{
    double total = 0;

    for(int i=0;i<pedidos.size();i++)
    {
        total += pedidos[i].getPreco() * pedidos[i].getQuantidade();
    }
    return total;
}
