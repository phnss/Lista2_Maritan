#include <iostream>
#include <locale>

#include "Conta.h"
#include "ContaEspecial.h"
using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    Conta conta1 = Conta("Jo�o Everaldo", 7000.50, 1234, 5000);
    ContaEspecial conta2 = ContaEspecial("Pedro Alexandre", 5000, 4321, 0);

    conta1.definirLimite();
    conta2.definirLimite();

    cout << "//-----------------------Clientes-----------------------//" << endl;
    cout << "Cliente: " << conta1.getNomeCliente() << endl;
    cout << "N�mero da conta: " << conta1.getNumeroConta() << endl;
    cout << "S�lario mensal: " << conta1.getSalarioMensal() << endl;
    cout << "Saldo: " << conta1.getSaldo() << endl;
    cout << "Limite da conta: " << conta1.getLimite() << endl;

    cout << endl;

    cout << "Cliente: " << conta2.getNomeCliente() << endl;
    cout << "N�mero da conta: " << conta2.getNumeroConta() << endl;
    cout << "S�lario mensal: " << conta2.getSalarioMensal() << endl;
    cout << "Saldo: " << conta2.getSaldo() << endl;
    cout << "Limite da conta: " << conta2.getLimite() << endl;

    cout << "//-----------------------Teste da Exception-----------------------//" << endl;
    cout << "Tentaremos sacar 6000 da conta de " << conta1.getNomeCliente() << ", que possui: ";
    cout << conta1.getSaldo() << " em seu saldo." << endl;

    try{

        conta1.sacar(6000);

    }catch(SaldoNaoDisponivelException error){
        cout<< error.what() <<endl;
    }

    cout << "Saldo: " << conta1.getSaldo() << endl;

    return 0;
}
