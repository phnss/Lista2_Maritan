#ifndef VALORABAIXOEXCEPTION_H
#define VALORABAIXOEXCEPTION_H

#include <exception>

class ValorAbaixoException : public std::exception
{
    public:
        ValorAbaixoException();

        const char *what();

    private:
};

#endif // VALORABAIXOEXCEPTION_H
