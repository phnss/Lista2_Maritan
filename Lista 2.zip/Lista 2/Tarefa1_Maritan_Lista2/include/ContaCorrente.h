#ifndef CONTACORRENTE_H
#define CONTACORRENTE_H


class ContaCorrente
{
    public:
        ContaCorrente();
        virtual ~ContaCorrente();

    protected:

    private:
};

#endif // CONTACORRENTE_H
