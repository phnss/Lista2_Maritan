#include "RestauranteCaseiro.h"

//------------CONSTRUTOR------------
RestauranteCaseiro::RestauranteCaseiro()
{
    //ctor
}
//------------GET-------------------

//------------SET-------------------

//------------M�TODOS---------------
void RestauranteCaseiro::adicionaAoPedido(Pedido pedido, int numMesa)
{
    mesas[numMesa].adicionaAoPedido(pedido);
}
double RestauranteCaseiro::calculaTotalRestaurante()
{
    double total = 0;

    for(int i=0;i<mesas.size();i++)
    {
        total += mesas[i].calculaTotal();
    }
    return total;
}
void RestauranteCaseiro::adicionaMesa(MesaDeRestaurante mesa)
{
    mesas.push_back(mesa);
}
