#ifndef DATA_H
#define DATA_H

#include <fstream>

class Data
{
    friend std::ofstream&operator<<(std::ofstream &, const Data &);

    private:
};

#endif // DATA_H
