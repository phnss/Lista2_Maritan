#ifndef VALORACIMAEXCEPTION_H
#define VALORACIMAEXCEPTION_H

#include <exception>

class ValorAcimaException : public std::exception
{
    public:
        ValorAcimaException();

        const char* what();

    private:
};

#endif // VALORACIMAEXCEPTION_H
