#include "ValorAbaixoException.h"

ValorAbaixoException::ValorAbaixoException()
{
    //ctor
}

const char* ValorAbaixoException::what()
{
    return "Valor abaixo do esperado.";
}
