#include <iostream>
#include <locale>

#include "Pedido.h"
#include "MesaDeRestaurante.h"
#include "RestauranteCaseiro.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    Pedido p1 = Pedido(01, "Fil� apimentado ao ponto", 1, 20.0);
    Pedido p2 = Pedido(02, "Coca-Cola em lata", 3, 4.5);
    Pedido p3 = Pedido(03, "Pudim de Leite", 1, 8.0);
    Pedido p4 = Pedido(04, "Tambaqui", 2, 15.0);
    Pedido p5 = Pedido(05, "Suco de laranja", 4, 4.5);
    Pedido p6 = Pedido(06, "Birgadeiros", 1, 5.0);

    MesaDeRestaurante m1;
    MesaDeRestaurante m2;

    RestauranteCaseiro adm;

    m1.adicionaAoPedido(p1);m1.adicionaAoPedido(p2);m1.adicionaAoPedido(p3);
    m2.adicionaAoPedido(p4);m2.adicionaAoPedido(p5);m2.adicionaAoPedido(p6);

    adm.adicionaMesa(m1);adm.adicionaMesa(m2);
    //m1.zeraPedidos();
    //m2.zeraPedidos();

    cout << "Valor total pela mesa de n�mero 1: " << m1.calculaTotal() << endl;
    cout << "Valor total pela mesa de n�mero 2: " << m2.calculaTotal() << endl;

    cout << "Valor total do restaurante: " << adm.calculaTotalRestaurante() << endl;

    return 0;
}
