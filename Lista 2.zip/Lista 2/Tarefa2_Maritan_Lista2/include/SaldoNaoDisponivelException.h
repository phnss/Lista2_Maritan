#ifndef SALDONAODISPONIVELEXCEPTION_H
#define SALDONAODISPONIVELEXCEPTION_H

#include <exception>

class SaldoNaoDisponivelException : public std::exception
{
    public:
        SaldoNaoDisponivelException();

        const char *what(){
            return "N�o � possivel concluir a transa��o por tentar sacar mais que o seu saldo.";
        }

    private:
};

#endif // SALDONAODISPONIVELEXCEPTION_H
