#include "IConta.h"

IConta::IConta()
{
    //ctor
}
