#ifndef MESADERESTAURANTE_H
#define MESADERESTAURANTE_H

#include <vector>

#include "Pedido.h"

class MesaDeRestaurante
{
    public:
//------------CONSTRUTOR------------
        MesaDeRestaurante();
        MesaDeRestaurante(Pedido pedido);
//------------GET-------------------

//------------SET-------------------

//------------M�TODOS---------------
        void adicionaAoPedido(Pedido pedido);
        void zeraPedidos();
        double calculaTotal();
    private:
        std::vector<Pedido>pedidos;
};

#endif // MESADERESTAURANTE_H
